# Express Cargo Ops — Pack (Offline Mini ERP)

This package is an upgraded, multi-file version of the Express Cargo Ops dashboard:
- Products, Orders, Shipments, Inventory, Finance
- **Live tracking view** (simulated live feed + manual tracking updates; ready to connect to real tracking APIs)
- **Report uploads** (PDF/CSV/JSON) stored locally in the browser (IndexedDB)
- Import/Export full database JSON
- Works offline (PWA Service Worker)

## How to run
### Option A (recommended): run a tiny local server
Because browsers restrict some features on `file://`, use a local server:

**Python**
```bash
cd express_ops_pack
python -m http.server 8080
```
Open: http://localhost:8080

### Option B: open index.html directly
Some features (service worker / some file APIs) may be limited.

## Where your data is stored
- Database: LocalStorage (fast)
- Uploaded reports: IndexedDB (large files)

## Connect to real tracking
Open `app.js` → find `TRACKING_PROVIDERS`.
Replace the demo provider with your courier/airline tracking API calls.
