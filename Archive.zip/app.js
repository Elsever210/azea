// Express Cargo Ops — Pack
// - DB: LocalStorage
// - Reports: IndexedDB
// - Live tracking: demo provider + timer (plug your real APIs)

const LS_KEY = "express_ops_pack_v1";

// ---------- DB ----------
const defaultDB = () => ({
  meta: { company:"", cnWh:"Guangzhou", azWh:"Baku", currency:"USD" },
  products: [],
  orders: [],
  shipments: [],
  inventory: {}, // sku -> onHand
  tracking: {},  // shipmentId -> [{ts, event, loc, source}]
  liveLog: [],   // [{ts, shipmentId, msg}]
});

let db = loadDB();

function loadDB(){
  try{
    const raw = localStorage.getItem(LS_KEY);
    if(!raw) return defaultDB();
    const parsed = JSON.parse(raw);
    return { ...defaultDB(), ...parsed };
  }catch{ return defaultDB(); }
}
function saveDB(){ localStorage.setItem(LS_KEY, JSON.stringify(db)); }

const $ = (id)=>document.getElementById(id);

function uid(prefix){
  const t = Date.now().toString(36);
  const r = Math.random().toString(36).slice(2,7);
  return `${prefix}-${t}-${r}`.toUpperCase();
}
function escapeHTML(s){
  return String(s ?? "").replace(/[&<>"']/g, m => ({
    "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"
  }[m]));
}
function money(n){
  const cur = (db.meta.currency || "USD").toUpperCase();
  const val = Number(n||0);
  return (cur==="USD" ? "$" : (cur+" ")) + val.toFixed(2);
}

// ---------- NAV ----------
function setActiveView(view){
  document.querySelectorAll("section[id^='view-']").forEach(s=>s.classList.add("hidden"));
  $("view-"+view).classList.remove("hidden");
  document.querySelectorAll(".navbtn").forEach(b=>b.classList.toggle("active", b.dataset.view===view));
  refreshAll();
}
$("nav").addEventListener("click",(e)=>{
  const btn = e.target.closest(".navbtn");
  if(!btn) return;
  setActiveView(btn.dataset.view);
});

// ---------- Export/Import/Wipe ----------
$("btnExport").addEventListener("click",()=>{
  const blob = new Blob([JSON.stringify(db,null,2)], {type:"application/json"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "express_ops_db.json";
  a.click();
  URL.revokeObjectURL(a.href);
});

$("fileImport").addEventListener("change",(e)=>{
  const file = e.target.files?.[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try{
      const imported = JSON.parse(reader.result);
      db = { ...defaultDB(), ...imported };
      saveDB();
      refreshAll();
      alert("Imported successfully.");
    }catch{
      alert("Import failed: invalid JSON");
    }
  };
  reader.readAsText(file);
  e.target.value = "";
});

$("btnWipe").addEventListener("click", async ()=>{
  if(!confirm("Wipe ALL data (DB + uploaded reports)?")) return;
  db = defaultDB();
  saveDB();
  await reportsClearAll();
  refreshAll();
});

// ---------- PWA install + SW ----------
let deferredPrompt = null;
window.addEventListener("beforeinstallprompt",(e)=>{
  e.preventDefault();
  deferredPrompt = e;
  $("btnInstall").style.display = "";
});
$("btnInstall").addEventListener("click", async ()=>{
  if(!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null;
  $("btnInstall").style.display = "none";
});
if("serviceWorker" in navigator){
  window.addEventListener("load",()=>{
    navigator.serviceWorker.register("./sw.js").catch(()=>{});
  });
}

// ---------- UI helpers ----------
function statusTag(status){
  const map = {
    NEW:["yellow","NEW"],
    PAID:["green","PAID"],
    PICK_PACK:["yellow","PICK/PACK"],
    SHIPPED:["yellow","SHIPPED"],
    DELIVERED:["green","DELIVERED"],
    CANCELLED:["red","CANCELLED"]
  };
  const [c,label] = map[status] || ["yellow",status];
  return `<span class="tag"><span class="dot ${c}"></span>${label}</span>`;
}
function shipmentTag(status){
  const map = {
    CREATED:["yellow","CREATED"],
    AT_CN_WAREHOUSE:["yellow","AT CN WH"],
    IN_TRANSIT:["yellow","IN TRANSIT"],
    CUSTOMS:["yellow","CUSTOMS"],
    AT_AZ_WAREHOUSE:["yellow","AT AZ WH"],
    DELIVERED:["green","DELIVERED"]
  };
  const [c,label] = map[status] || ["yellow",status];
  return `<span class="tag"><span class="dot ${c}"></span>${label}</span>`;
}
function orderTotal(o){
  let total = 0;
  (o.items||[]).forEach(it=>{
    const p = db.products.find(x=>x.sku===it.sku);
    total += Number(p?.sell||0) * Number(it.qty||0);
  });
  return total;
}
function orderItemCount(o){
  return (o.items||[]).reduce((a,it)=>a+Number(it.qty||0),0);
}

// ---------- PRODUCTS ----------
let editingProductSKU = null;

$("btnAddProduct").addEventListener("click",()=>{ clearProductForm(); $("pSKU").focus(); });
$("btnSaveProduct").addEventListener("click", saveProductFromForm);
$("btnClearProduct").addEventListener("click", clearProductForm);
$("prodSearch").addEventListener("input", renderProducts);

$("tblProducts").addEventListener("click",(e)=>{
  const btn = e.target.closest("button[data-act]");
  if(!btn) return;
  const act = btn.dataset.act;
  const sku = btn.dataset.sku;
  const p = db.products.find(x=>x.sku===sku);
  if(!p) return;

  if(act==="edit"){
    editingProductSKU = p.sku;
    $("pSKU").value = p.sku;
    $("pName").value = p.name;
    $("pHS").value = p.hs||"";
    $("pFragile").value = p.fragile||"no";
    $("pCost").value = p.cost ?? 0;
    $("pSell").value = p.sell ?? 0;
    $("pNotes").value = p.notes||"";
    setActiveView("products");
  }
  if(act==="del"){
    if(!confirm(`Delete product ${sku}?`)) return;
    db.products = db.products.filter(x=>x.sku!==sku);
    delete db.inventory[sku];
    db.orders.forEach(o=>{ o.items = (o.items||[]).filter(i=>i.sku!==sku); });
    saveDB();
    refreshAll();
  }
});

function clearProductForm(){
  editingProductSKU = null;
  ["pSKU","pName","pHS","pCost","pSell","pNotes"].forEach(id=>$(id).value="");
  $("pFragile").value="no";
}

function saveProductFromForm(){
  const sku = $("pSKU").value.trim().toUpperCase();
  const name = $("pName").value.trim();
  if(!sku || !name){ alert("SKU and Name are required."); return; }
  const hs = $("pHS").value.trim();
  const fragile = $("pFragile").value;
  const cost = Number($("pCost").value||0);
  const sell = Number($("pSell").value||0);
  const notes = $("pNotes").value.trim();

  const existsIdx = db.products.findIndex(p=>p.sku===sku);
  if(editingProductSKU && editingProductSKU!==sku){
    if(existsIdx>=0){ alert("SKU already exists."); return; }
    const oldIdx = db.products.findIndex(p=>p.sku===editingProductSKU);
    if(oldIdx>=0) db.products.splice(oldIdx,1);
  }else if(!editingProductSKU && existsIdx>=0){
    alert("SKU already exists."); return;
  }

  db.products.push({ sku, name, hs, fragile, cost, sell, notes });
  db.products.sort((a,b)=>a.sku.localeCompare(b.sku));
  if(!(sku in db.inventory)) db.inventory[sku] = db.inventory[sku] ?? 0;

  saveDB();
  clearProductForm();
  refreshAll();
}

function renderProducts(){
  const q = ($("prodSearch").value||"").toLowerCase().trim();
  const rows = db.products
    .filter(p=>{
      const hay = `${p.sku} ${p.name} ${p.hs||""}`.toLowerCase();
      return !q || hay.includes(q);
    })
    .map(p=>{
      const frag = p.fragile==="yes"
        ? `<span class="tag"><span class="dot red"></span>Yes</span>`
        : `<span class="tag"><span class="dot green"></span>No</span>`;
      return `<tr>
        <td class="mono">${escapeHTML(p.sku)}</td>
        <td>${escapeHTML(p.name)}</td>
        <td class="mono">${escapeHTML(p.hs||"")}</td>
        <td class="mono">${money(p.cost)}</td>
        <td class="mono">${money(p.sell)}</td>
        <td>${frag}</td>
        <td>
          <button class="btn ghost small" data-act="edit" data-sku="${escapeHTML(p.sku)}">Edit</button>
          <button class="btn ghost small" data-act="del" data-sku="${escapeHTML(p.sku)}">Delete</button>
        </td>
      </tr>`;
    }).join("");
  $("tblProducts").innerHTML = rows || `<tr><td colspan="7" class="muted">No products yet.</td></tr>`;
  rebuildPickers();
}

// ---------- ORDERS ----------
let editingOrderId = null;
let draftItems = [];

$("btnAddOrder").addEventListener("click",()=>{ clearOrderForm(); $("oCustomer").focus(); });
$("btnAddItem").addEventListener("click", addDraftItem);
$("btnSaveOrder").addEventListener("click", saveOrderFromForm);
$("btnClearOrder").addEventListener("click", clearOrderForm);
$("orderSearch").addEventListener("input", renderOrders);

$("oItems").addEventListener("click",(e)=>{
  const b = e.target.closest("button[data-idx]");
  if(!b) return;
  const idx = Number(b.dataset.idx);
  draftItems.splice(idx,1);
  renderDraftItems();
});

$("tblOrders").addEventListener("click",(e)=>{
  const btn = e.target.closest("button[data-act]");
  if(!btn) return;
  const act = btn.dataset.act;
  const id = btn.dataset.id;
  const o = db.orders.find(x=>x.id===id);
  if(!o) return;

  if(act==="edit"){
    editingOrderId = o.id;
    $("oCustomer").value = o.customer||"";
    $("oPhone").value = o.phone||"";
    $("oAddress").value = o.address||"";
    $("oStatus").value = o.status||"NEW";
    $("oLogistics").value = o.logistics||0;
    $("oCustoms").value = o.customs||0;
    $("oNotes").value = o.notes||"";
    draftItems = (o.items||[]).map(x=>({ ...x }));
    renderDraftItems();
    setActiveView("orders");
  }
  if(act==="del"){
    if(!confirm(`Delete order ${id}?`)) return;
    db.shipments.forEach(s=>{ s.orderIds = (s.orderIds||[]).filter(oid=>oid!==id); });
    db.orders = db.orders.filter(x=>x.id!==id);
    saveDB();
    refreshAll();
  }
});

function calcDraftTotal(){
  let total = 0;
  draftItems.forEach(it=>{
    const p = db.products.find(x=>x.sku===it.sku);
    const sell = p ? Number(p.sell||0) : 0;
    total += sell * Number(it.qty||0);
  });
  $("oTotal").textContent = money(total);
  return total;
}
function renderDraftItems(){
  const rows = draftItems.map((it,idx)=>{
    const p = db.products.find(x=>x.sku===it.sku);
    const name = p?.name || "";
    const sell = Number(p?.sell||0);
    const line = sell * Number(it.qty||0);
    return `<tr>
      <td class="mono">${escapeHTML(it.sku)}</td>
      <td>${escapeHTML(name)}</td>
      <td class="mono">${escapeHTML(String(it.qty))}</td>
      <td class="mono">${money(sell)}</td>
      <td class="mono">${money(line)}</td>
      <td><button class="btn ghost small" data-idx="${idx}">Remove</button></td>
    </tr>`;
  }).join("");
  $("oItems").innerHTML = rows || `<tr><td colspan="6" class="muted">No items yet.</td></tr>`;
  calcDraftTotal();
}
function clearOrderForm(){
  editingOrderId = null;
  draftItems = [];
  ["oCustomer","oPhone","oAddress","oLogistics","oCustoms","oNotes"].forEach(id=>$(id).value="");
  $("oStatus").value = "NEW";
  $("oQty").value = "";
  renderDraftItems();
}
function addDraftItem(){
  const sku = $("oProduct").value;
  const qty = Number($("oQty").value||0);
  if(!sku){ alert("Select a product."); return; }
  if(!qty || qty<1){ alert("Qty must be >= 1."); return; }
  const existing = draftItems.find(x=>x.sku===sku);
  if(existing) existing.qty += qty;
  else draftItems.push({ sku, qty });
  $("oQty").value = "";
  renderDraftItems();
}
function saveOrderFromForm(){
  const customer = $("oCustomer").value.trim();
  if(!customer){ alert("Customer name is required."); return; }
  if(!draftItems.length){ alert("Add at least 1 item."); return; }

  const status = $("oStatus").value;
  const phone = $("oPhone").value.trim();
  const address = $("oAddress").value.trim();
  const logistics = Number($("oLogistics").value||0);
  const customs = Number($("oCustoms").value||0);
  const notes = $("oNotes").value.trim();

  const order = {
    id: editingOrderId || uid("ORD"),
    customer, phone, address, status,
    items: draftItems.map(x=>({ ...x })),
    logistics, customs, notes,
    createdAt: editingOrderId ? (db.orders.find(o=>o.id===editingOrderId)?.createdAt || new Date().toISOString()) : new Date().toISOString(),
    shipmentId: (db.orders.find(o=>o.id===editingOrderId)?.shipmentId) || ""
  };

  const idx = db.orders.findIndex(o=>o.id===order.id);
  if(idx>=0) db.orders[idx] = order;
  else db.orders.unshift(order);

  saveDB();
  clearOrderForm();
  refreshAll();
}

function renderOrders(){
  const q = ($("orderSearch").value||"").toLowerCase().trim();
  const rows = db.orders
    .filter(o=>{
      const hay = `${o.id} ${o.customer}`.toLowerCase();
      return !q || hay.includes(q);
    })
    .map(o=>{
      const total = orderTotal(o);
      const ship = o.shipmentId ? `<span class="mono">${escapeHTML(o.shipmentId)}</span>` : `<span class="muted">—</span>`;
      return `<tr>
        <td class="mono">${escapeHTML(o.id)}</td>
        <td>${escapeHTML(o.customer)}</td>
        <td>${statusTag(o.status)}</td>
        <td class="mono">${orderItemCount(o)}</td>
        <td class="mono">${money(total)}</td>
        <td>${ship}</td>
        <td>
          <button class="btn ghost small" data-act="edit" data-id="${escapeHTML(o.id)}">Edit</button>
          <button class="btn ghost small" data-act="del" data-id="${escapeHTML(o.id)}">Delete</button>
        </td>
      </tr>`;
    }).join("");
  $("tblOrders").innerHTML = rows || `<tr><td colspan="7" class="muted">No orders yet.</td></tr>`;
  rebuildPickers();
}

// ---------- SHIPMENTS ----------
let editingShipmentId = null;

$("btnAddShipment").addEventListener("click",()=>{ clearShipmentForm(); $("sAWB").focus(); });
$("btnSaveShipment").addEventListener("click", saveShipmentFromForm);
$("btnClearShipment").addEventListener("click", clearShipmentForm);
$("shipSearch").addEventListener("input", renderShipments);

$("tblShipments").addEventListener("click",(e)=>{
  const btn = e.target.closest("button[data-act]");
  if(!btn) return;
  const act = btn.dataset.act;
  const id = btn.dataset.id;
  const s = db.shipments.find(x=>x.id===id);
  if(!s) return;

  if(act==="edit"){
    editingShipmentId = s.id;
    $("sRoute").value = s.route||"CN→AZ Air Express";
    $("sStatus").value = s.status||"CREATED";
    $("sETA").value = s.eta||"";
    $("sAWB").value = s.awb||"";
    const set = new Set(s.orderIds||[]);
    Array.from($("sOrders").options).forEach(o=>o.selected = set.has(o.value));
    setActiveView("shipments");
  }
  if(act==="del"){
    if(!confirm(`Delete shipment ${id}?`)) return;
    db.shipments = db.shipments.filter(x=>x.id!==id);
    db.orders.forEach(o=>{ if(o.shipmentId===id) o.shipmentId=""; });
    delete db.tracking[id];
    saveDB();
    refreshAll();
  }
});

function clearShipmentForm(){
  editingShipmentId = null;
  $("sRoute").value = "CN→AZ Air Express";
  $("sStatus").value = "CREATED";
  $("sETA").value = "";
  $("sAWB").value = "";
  Array.from($("sOrders").options).forEach(o=>o.selected=false);
}

function saveShipmentFromForm(){
  const route = $("sRoute").value;
  const status = $("sStatus").value;
  const eta = $("sETA").value;
  const awb = $("sAWB").value.trim();
  const orderIds = Array.from($("sOrders").selectedOptions).map(o=>o.value);

  const s = {
    id: editingShipmentId || uid("SHP"),
    route, status, eta, awb,
    orderIds,
    createdAt: editingShipmentId ? (db.shipments.find(x=>x.id===editingShipmentId)?.createdAt || new Date().toISOString()) : new Date().toISOString()
  };

  const idx = db.shipments.findIndex(x=>x.id===s.id);
  if(idx>=0) db.shipments[idx] = s;
  else db.shipments.unshift(s);

  db.orders.forEach(o=>{
    if(orderIds.includes(o.id)) o.shipmentId = s.id;
    else if(o.shipmentId===s.id) o.shipmentId = "";
  });

  // init tracking store
  db.tracking[s.id] = db.tracking[s.id] || [];

  saveDB();
  clearShipmentForm();
  refreshAll();
}

function renderShipments(){
  const q = ($("shipSearch").value||"").toLowerCase().trim();
  const rows = db.shipments
    .filter(s=>{
      const hay = `${s.id} ${s.awb||""}`.toLowerCase();
      return !q || hay.includes(q);
    })
    .map(s=>{
      const orders = (s.orderIds||[]).length
        ? (s.orderIds||[]).map(x=>`<span class="mono">${escapeHTML(x)}</span>`).join("<br>")
        : `<span class="muted">—</span>`;
      return `<tr>
        <td class="mono">${escapeHTML(s.id)}</td>
        <td>${escapeHTML(s.route||"")}</td>
        <td>${shipmentTag(s.status)}</td>
        <td class="mono">${escapeHTML(s.eta||"")}</td>
        <td class="mono">${escapeHTML(s.awb||"")}</td>
        <td>${orders}</td>
        <td>
          <button class="btn ghost small" data-act="edit" data-id="${escapeHTML(s.id)}">Edit</button>
          <button class="btn ghost small" data-act="del" data-id="${escapeHTML(s.id)}">Delete</button>
        </td>
      </tr>`;
    }).join("");
  $("tblShipments").innerHTML = rows || `<tr><td colspan="7" class="muted">No shipments yet.</td></tr>`;
  rebuildPickers();
}

// ---------- TRACKING (Live) ----------
const TRACKING_PROVIDERS = {
  // Demo provider: generates realistic progress events based on shipment status
  demo: async (shipment) => {
    const now = new Date();
    const steps = [
      {event:"Shipment created", loc: db.meta.cnWh},
      {event:"Arrived at China warehouse", loc: db.meta.cnWh},
      {event:"Departed origin", loc: db.meta.cnWh},
      {event:"Arrived at transit hub", loc:"Transit hub"},
      {event:"Customs clearance started", loc: db.meta.azWh},
      {event:"Arrived at AZ warehouse", loc: db.meta.azWh},
      {event:"Out for delivery", loc: db.meta.azWh},
      {event:"Delivered", loc: db.meta.azWh},
    ];
    // choose next step based on existing events count
    const existing = db.tracking[shipment.id] || [];
    const nextIdx = Math.min(existing.length, steps.length-1);
    const pick = steps[nextIdx];
    return [{ ts: now.toISOString(), event: pick.event, loc: pick.loc, source:"demo" }];
  }
};

let liveTimer = null;

$("btnTrackNow").addEventListener("click", async ()=>{
  const id = $("tShipment").value;
  if(!id){ alert("No shipment."); return; }
  const s = db.shipments.find(x=>x.id===id);
  if(!s){ alert("Shipment not found."); return; }
  await trackShipment(s);
  refreshAll();
});

$("btnStartLive").addEventListener("click", ()=>{
  if(liveTimer) return;
  liveTimer = setInterval(async ()=>{
    // rotate through shipments
    for(const s of db.shipments.slice(0,6)){
      await trackShipment(s, true);
    }
    refreshAllTrackingLogs();
  }, 3000);
  $("tLiveLog").textContent = "Live started...";
});

$("btnStopLive").addEventListener("click", ()=>{
  if(liveTimer){ clearInterval(liveTimer); liveTimer = null; }
  $("tLiveLog").textContent = "Live is off.";
});

$("btnAddEvent").addEventListener("click", ()=>{
  const id = $("tShipment").value;
  if(!id){ alert("Select a shipment."); return; }
  const event = $("tEvent").value.trim();
  if(!event){ alert("Event is required."); return; }
  const loc = $("tLoc").value.trim();
  const ts = new Date().toISOString();
  db.tracking[id] = db.tracking[id] || [];
  db.tracking[id].unshift({ ts, event, loc, source:"manual" });
  db.liveLog.unshift({ ts, shipmentId:id, msg:`[manual] ${event}${loc?` @ ${loc}`:""}` });
  db.liveLog = db.liveLog.slice(0,200);
  saveDB();
  $("tEvent").value=""; $("tLoc").value="";
  refreshAll();
});

$("tShipment").addEventListener("change", refreshAll);

async function trackShipment(shipment, quiet=false){
  const provider = TRACKING_PROVIDERS.demo;
  const events = await provider(shipment);
  db.tracking[shipment.id] = db.tracking[shipment.id] || [];
  for(const ev of events){
    // de-dup by ts+event
    const key = ev.ts + "|" + ev.event;
    const exists = (db.tracking[shipment.id]).some(x => (x.ts + "|" + x.event) === key);
    if(!exists){
      db.tracking[shipment.id].unshift(ev);
      if(!quiet){
        db.liveLog.unshift({ ts: ev.ts, shipmentId: shipment.id, msg:`[${ev.source}] ${ev.event}${ev.loc?` @ ${ev.loc}`:""}` });
      }else{
        db.liveLog.unshift({ ts: ev.ts, shipmentId: shipment.id, msg:`[${ev.source}] ${shipment.id}: ${ev.event}` });
      }
    }
  }
  db.liveLog = db.liveLog.slice(0,200);
  saveDB();
}

function renderTracking(){
  const opts = db.shipments.map(s=>{
    const label = `${s.id}${s.awb?` • ${s.awb}`:""}`;
    return `<option value="${escapeHTML(s.id)}">${escapeHTML(label)}</option>`;
  }).join("");
  $("tShipment").innerHTML = opts || `<option value="">No shipments</option>`;

  // keep selection if possible
  const cur = $("tShipment").value;
  const first = db.shipments[0]?.id || "";
  const selected = db.shipments.some(s=>s.id===cur) ? cur : first;
  $("tShipment").value = selected;

  // timeline
  if(!selected){
    $("tTimeline").textContent = "Select a shipment...";
  }else{
    const events = db.tracking[selected] || [];
    $("tTimeline").textContent = events.length
      ? events.map(e=>`${e.ts.slice(0,19).replace("T"," ")} • ${e.source} • ${e.event}${e.loc?` @ ${e.loc}`:""}`).join("\n")
      : "No events yet. Click Track Now or Start Live.";
  }

  refreshAllTrackingLogs();
}

function refreshAllTrackingLogs(){
  const lines = (db.liveLog||[]).slice(0,80).map(e=>{
    const t = (e.ts||"").slice(0,19).replace("T"," ");
    return `${t} • ${e.shipmentId} • ${e.msg}`;
  });
  $("tLiveLog").textContent = lines.length ? lines.join("\n") : (liveTimer ? "Live started..." : "Live is off.");
}

// ---------- REPORTS (IndexedDB) ----------
const IDB_NAME = "express_ops_reports_v1";
const IDB_STORE = "reports";

function idbOpen(){
  return new Promise((resolve,reject)=>{
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => {
      const dbi = req.result;
      const store = dbi.createObjectStore(IDB_STORE, { keyPath:"id" });
      store.createIndex("by_link", ["linkType","linkId"], { unique:false });
      store.createIndex("by_name", "name", { unique:false });
    };
    req.onsuccess = ()=>resolve(req.result);
    req.onerror = ()=>reject(req.error);
  });
}
async function reportsPut(rec){
  const dbi = await idbOpen();
  return new Promise((resolve,reject)=>{
    const tx = dbi.transaction(IDB_STORE,"readwrite");
    tx.objectStore(IDB_STORE).put(rec);
    tx.oncomplete = ()=>resolve(true);
    tx.onerror = ()=>reject(tx.error);
  });
}
async function reportsGetAll(){
  const dbi = await idbOpen();
  return new Promise((resolve,reject)=>{
    const tx = dbi.transaction(IDB_STORE,"readonly");
    const req = tx.objectStore(IDB_STORE).getAll();
    req.onsuccess = ()=>resolve(req.result||[]);
    req.onerror = ()=>reject(req.error);
  });
}
async function reportsDelete(id){
  const dbi = await idbOpen();
  return new Promise((resolve,reject)=>{
    const tx = dbi.transaction(IDB_STORE,"readwrite");
    tx.objectStore(IDB_STORE).delete(id);
    tx.oncomplete = ()=>resolve(true);
    tx.onerror = ()=>reject(tx.error);
  });
}
async function reportsClearAll(){
  const dbi = await idbOpen();
  return new Promise((resolve,reject)=>{
    const tx = dbi.transaction(IDB_STORE,"readwrite");
    tx.objectStore(IDB_STORE).clear();
    tx.oncomplete = ()=>resolve(true);
    tx.onerror = ()=>reject(tx.error);
  });
}

$("rLinkType").addEventListener("change", rebuildReportLinkPicker);
$("rSearch").addEventListener("input", renderReports);
$("rFile").addEventListener("change", async (e)=>{
  const file = e.target.files?.[0];
  if(!file) return;

  const linkType = $("rLinkType").value;
  const linkId = $("rLinkId").value || "";
  const tag = $("rTag").value.trim();

  const id = uid("REP");
  const buf = await file.arrayBuffer();
  const rec = {
    id,
    name: file.name,
    mime: file.type || "application/octet-stream",
    size: file.size,
    tag,
    linkType: linkType==="none" ? "none" : linkType,
    linkId: linkType==="none" ? "" : linkId,
    uploadedAt: new Date().toISOString(),
    data: buf
  };
  await reportsPut(rec);
  e.target.value = "";
  $("rTag").value = "";
  await renderReports();
  alert("Uploaded (stored locally).");
});

$("tblReports").addEventListener("click", async (e)=>{
  const btn = e.target.closest("button[data-act]");
  if(!btn) return;
  const act = btn.dataset.act;
  const id = btn.dataset.id;
  const all = await reportsGetAll();
  const rec = all.find(x=>x.id===id);
  if(!rec) return;

  if(act==="dl"){
    const blob = new Blob([rec.data], {type: rec.mime});
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = rec.name;
    a.click();
    URL.revokeObjectURL(a.href);
  }
  if(act==="del"){
    if(!confirm("Delete this report (local)?")) return;
    await reportsDelete(id);
    await renderReports();
  }
});

async function renderReports(){
  const q = ($("rSearch").value||"").toLowerCase().trim();
  const all = await reportsGetAll();
  const filtered = all.filter(r=>{
    const hay = `${r.name} ${r.tag||""} ${r.linkType||""} ${r.linkId||""}`.toLowerCase();
    return !q || hay.includes(q);
  }).sort((a,b)=> (b.uploadedAt||"").localeCompare(a.uploadedAt||""));

  const rows = filtered.map(r=>{
    const linked = r.linkType==="none" ? "—" : `${r.linkType}: ${r.linkId||"—"}`;
    return `<tr>
      <td class="mono">${escapeHTML(r.name)}</td>
      <td class="mono">${escapeHTML(r.mime||"")}</td>
      <td>${escapeHTML(r.tag||"")}</td>
      <td class="mono">${escapeHTML(linked)}</td>
      <td class="mono">${escapeHTML(String(r.size||0))}</td>
      <td class="mono">${escapeHTML((r.uploadedAt||"").slice(0,10))}</td>
      <td>
        <button class="btn ghost small" data-act="dl" data-id="${escapeHTML(r.id)}">Download</button>
        <button class="btn ghost small" data-act="del" data-id="${escapeHTML(r.id)}">Delete</button>
      </td>
    </tr>`;
  }).join("");

  $("tblReports").innerHTML = rows || `<tr><td colspan="7" class="muted">No reports uploaded.</td></tr>`;
}

function rebuildReportLinkPicker(){
  const type = $("rLinkType").value;
  let opts = "";
  if(type==="shipment"){
    opts = db.shipments.map(s=>`<option value="${escapeHTML(s.id)}">${escapeHTML(s.id)}${s.awb?` • ${escapeHTML(s.awb)}`:""}</option>`).join("");
  }else if(type==="order"){
    opts = db.orders.map(o=>`<option value="${escapeHTML(o.id)}">${escapeHTML(o.id)} • ${escapeHTML(o.customer)}</option>`).join("");
  }else{
    opts = `<option value="">—</option>`;
  }
  $("rLinkId").innerHTML = opts || `<option value="">—</option>`;
}

// ---------- INVENTORY ----------
$("btnAdjustInv").addEventListener("click", adjustInventory);
$("btnRebuildInventory").addEventListener("click", ()=>{
  if(!confirm("Rebuild inventory from DELIVERED orders? This overwrites on-hand quantities.")) return;
  rebuildInventoryFromOrders();
});
$("invSearch").addEventListener("input", renderInventory);

function adjustInventory(){
  const sku = $("invSKU").value;
  const delta = Number($("invDelta").value||0);
  if(!sku){ alert("Select a SKU."); return; }
  if(!delta){ alert("Enter + or - qty."); return; }
  db.inventory[sku] = Number(db.inventory[sku]||0) + delta;
  $("invDelta").value = "";
  saveDB();
  refreshAll();
}
function rebuildInventoryFromOrders(){
  const inv = {};
  db.products.forEach(p=>inv[p.sku]=0);
  db.orders.filter(o=>o.status==="DELIVERED").forEach(o=>{
    (o.items||[]).forEach(it=>{
      inv[it.sku] = Number(inv[it.sku]||0) - Number(it.qty||0);
    });
  });
  db.inventory = inv;
  saveDB();
  refreshAll();
}
function renderInventory(){
  const q = ($("invSearch").value||"").toLowerCase().trim();
  const rows = db.products
    .filter(p=>{
      const hay = `${p.sku} ${p.name}`.toLowerCase();
      return !q || hay.includes(q);
    })
    .map(p=>{
      const onHand = Number(db.inventory[p.sku]||0);
      const frag = p.fragile==="yes"
        ? `<span class="tag"><span class="dot red"></span>Yes</span>`
        : `<span class="tag"><span class="dot green"></span>No</span>`;
      return `<tr>
        <td class="mono">${escapeHTML(p.sku)}</td>
        <td>${escapeHTML(p.name)}</td>
        <td class="mono">${escapeHTML(String(onHand))}</td>
        <td>${frag}</td>
      </tr>`;
    }).join("");
  $("tblInventory").innerHTML = rows || `<tr><td colspan="4" class="muted">No products yet.</td></tr>`;
}

// ---------- FINANCE ----------
$("btnRecalcFinance").addEventListener("click", renderFinance);

function computeFinance(days){
  const now = Date.now();
  const cutoff = days ? (now - days*24*3600*1000) : 0;

  const orders = db.orders.filter(o=>{
    const t = Date.parse(o.createdAt||"") || 0;
    return !days || t>=cutoff;
  });

  let revenue = 0, cogs = 0, logistics = 0, customs = 0;

  orders.forEach(o=>{
    revenue += orderTotal(o);
    logistics += Number(o.logistics||0);
    customs += Number(o.customs||0);
    (o.items||[]).forEach(it=>{
      const p = db.products.find(x=>x.sku===it.sku);
      cogs += Number(p?.cost||0) * Number(it.qty||0);
    });
  });

  const costs = cogs + logistics + customs;
  const profit = revenue - costs;
  return { revenue, costs, profit };
}
function renderFinance(){
  const period = $("fPeriod").value;
  const days = period==="ALL" ? null : Number(period);
  const { revenue, costs, profit } = computeFinance(days);
  $("fRevenue").textContent = money(revenue);
  $("fCosts").textContent = money(costs);
  $("fProfit").textContent = money(profit);
}

// ---------- SETTINGS ----------
$("btnSaveSettings").addEventListener("click", ()=>{
  db.meta.company = $("setCompany").value.trim();
  db.meta.cnWh = $("setCnWh").value.trim() || "Guangzhou";
  db.meta.azWh = $("setAzWh").value.trim() || "Baku";
  db.meta.currency = ($("setCurrency").value.trim() || "USD").toUpperCase();
  saveDB();
  refreshAll();
  alert("Saved.");
});

function renderSettings(){
  $("setCompany").value = db.meta.company || "";
  $("setCnWh").value = db.meta.cnWh || "";
  $("setAzWh").value = db.meta.azWh || "";
  $("setCurrency").value = db.meta.currency || "USD";
}

// ---------- DASHBOARD ----------
function renderDashboard(){
  const openOrders = db.orders.filter(o=>!["DELIVERED","CANCELLED"].includes(o.status)).length;
  const transit = db.shipments.filter(s=>["IN_TRANSIT","CUSTOMS","AT_CN_WAREHOUSE"].includes(s.status)).length;
  const invCount = Object.values(db.inventory||{}).reduce((a,v)=>a+Number(v||0),0);
  const fin = computeFinance(null);

  $("kpiOpenOrders").textContent = openOrders;
  $("kpiTransit").textContent = transit;
  $("kpiInventory").textContent = invCount;
  $("kpiProfit").textContent = money(fin.profit);

  const recentOrders = db.orders.slice(0,10).map(o=>`<tr>
    <td class="mono">${escapeHTML(o.id)}</td>
    <td>${escapeHTML(o.customer)}</td>
    <td>${statusTag(o.status)}</td>
    <td class="mono">${money(orderTotal(o))}</td>
    <td class="mono">${escapeHTML((o.createdAt||"").slice(0,10))}</td>
  </tr>`).join("");
  $("dashOrders").innerHTML = recentOrders || `<tr><td colspan="5" class="muted">No orders yet.</td></tr>`;

  const latest = (db.liveLog||[]).slice(0,30).map(e=>{
    const t = (e.ts||"").slice(0,19).replace("T"," ");
    return `${t} • ${e.shipmentId} • ${e.msg}`;
  });
  $("dashTrackLog").textContent = latest.length ? latest.join("\n") : "No events yet.";
}

// ---------- PICKERS ----------
function rebuildPickers(){
  // product pickers
  const popts = db.products.map(p=>`<option value="${escapeHTML(p.sku)}">${escapeHTML(p.sku)} — ${escapeHTML(p.name)}</option>`).join("");
  $("oProduct").innerHTML = popts || `<option value="">No products</option>`;
  $("invSKU").innerHTML = popts || `<option value="">No products</option>`;

  // orders picker for shipments
  const oopts = db.orders.map(o=>`<option value="${escapeHTML(o.id)}">${escapeHTML(o.id)} — ${escapeHTML(o.customer)} (${o.status})</option>`).join("");
  $("sOrders").innerHTML = oopts || "";

  // report links
  rebuildReportLinkPicker();
}

// ---------- REFRESH ----------
async function refreshAll(){
  rebuildPickers();
  renderDashboard();
  renderProducts();
  renderOrders();
  renderShipments();
  renderTracking();
  await renderReports();
  renderInventory();
  renderFinance();
  renderSettings();
}

// ---------- INIT ----------
refreshAll();
